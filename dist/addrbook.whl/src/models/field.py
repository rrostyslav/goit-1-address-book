# Базовий клас Field, який представляє загальне поле даних
class Field:
    # Ініціалізатор класу Field
    def __init__(self, value):
        # Зберігає значення поля
        self.value = value
